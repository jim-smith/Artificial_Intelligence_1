
# We do not expect much alterations to these two Perl files, certainly not to 'mark-submission.pl' which simply facilitates the marking code inside the 'py-files' folder.

# The 'on-submission.pl' code is there to do additional checks and required alterations to the student's input code. E.g. 
#	1.	convert a .ipynb notebook file to pure .py Python file
#	2.	insert required headers/footers into the file (e.g. to count the number of times a function is called for efficiency testing)
#   3.  calls essential checks on what code is banned from being included in the student submission.
